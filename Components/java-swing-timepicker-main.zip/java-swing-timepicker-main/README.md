# java-swing-timepicker
Date : 29/08/2021<br/>
For more Visit my youtube : https://www.youtube.com/c/HelloWorld-Raven/featured
<br/><br/>
![2021-08-29_170847](https://user-images.githubusercontent.com/58245926/131247117-f42003c0-a497-49ea-8ec5-0d4cde5f3e09.png)

## Method
Method Name | Description
----------- | ------------
public void now(); | Set time picker to current time now
public String getSelectedTime(); | Get time picker selected
public void setDisplayText(JTextField displayText); | display currnet time picker to jtextfield
public void setForeground(Color color); | set color to time picker
public void setSelectedTime(Date date); | set time picker selected time to specific time
public void addEventTimePicker(EventTimePicker event); | this event run when time selected change
public void addActionListener(ActionListener event); | this event run when time picker is current show popup and user click ok
public void showPopup(Component com, int x, int y); | to popup time picker
<br/>
Support me by subscribe youtube channel
<hr/>
