package com.raven.event;

public interface EventTimePicker {

    public void timeSelected(String time);
}
